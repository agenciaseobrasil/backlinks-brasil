export default function FooterNote(){
  return null;
}
